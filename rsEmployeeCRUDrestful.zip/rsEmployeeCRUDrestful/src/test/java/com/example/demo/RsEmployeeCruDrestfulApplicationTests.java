package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsEmployeeCruDrestfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
